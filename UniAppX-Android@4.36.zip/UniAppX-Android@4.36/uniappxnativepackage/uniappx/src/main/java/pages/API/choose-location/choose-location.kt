@file:Suppress("UNCHECKED_CAST", "USELESS_CAST", "INAPPLICABLE_JVM_NAME", "UNUSED_ANONYMOUS_PARAMETER")
package uni.UNIHelloUniAppX;
import io.dcloud.uniapp.*;
import io.dcloud.uniapp.extapi.*;
import io.dcloud.uniapp.framework.*;
import io.dcloud.uniapp.runtime.*;
import io.dcloud.uniapp.vue.*;
import io.dcloud.uniapp.vue.shared.*;
import io.dcloud.unicloud.*;
import io.dcloud.uts.*;
import io.dcloud.uts.Map;
import io.dcloud.uts.Set;
import io.dcloud.uts.UTSAndroid;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.Deferred;
import kotlinx.coroutines.Dispatchers;
import kotlinx.coroutines.async;
import io.dcloud.uniapp.extapi.chooseLocation as uni_chooseLocation;
open class GenPagesAPIChooseLocationChooseLocation : BasePage {
    constructor(__ins: ComponentInternalInstance) : super(__ins) {
        onLoad(fun(_: OnLoadOptions) {
            stat_instance.onLoad(this);
        }
        , __ins);
        onPageShow(fun() {
            stat_instance.onShow(this);
        }
        , __ins);
        onPageHide(fun() {
            stat_instance.onHide(this);
        }
        , __ins);
        onUnload(fun() {
            stat_instance.onUnload(this);
        }
        , __ins);
    }
    @Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE")
    override fun `$render`(): Any? {
        val _ctx = this;
        val _cache = this.`$`.renderCache;
        val _component_page_head = resolveEasyComponent("page-head", GenComponentsPageHeadPageHeadClass);
        return createElementVNode("view", null, utsArrayOf(
            createVNode(_component_page_head, utsMapOf("title" to _ctx.title), null, 8, utsArrayOf(
                "title"
            )),
            createElementVNode("view", utsMapOf("class" to "uni-padding-wrap"), utsArrayOf(
                createElementVNode("view", utsMapOf("class" to "uni-column content"), utsArrayOf(
                    createElementVNode("text", utsMapOf("class" to "uni-hello-text"), "位置信息"),
                    if (isTrue(!_ctx.hasLocation)) {
                        createElementVNode("text", utsMapOf("key" to 0, "class" to "uni-title-text uni-common-mt"), "未选择位置");
                    } else {
                        createCommentVNode("v-if", true);
                    }
                    ,
                    if (isTrue(_ctx.hasLocation)) {
                        createElementVNode("view", utsMapOf("key" to 1, "style" to normalizeStyle(utsMapOf("align-items" to "center"))), utsArrayOf(
                            createElementVNode("text", utsMapOf("class" to "uni-common-mt"), toDisplayString(_ctx.locationAddress), 1),
                            if (_ctx.location.latitude.length > 1) {
                                createElementVNode("view", utsMapOf("key" to 0, "class" to "uni-common-mt"), utsArrayOf(
                                    createElementVNode("text", null, "E: " + toDisplayString(_ctx.location.longitude[0]) + "°" + toDisplayString(_ctx.location.longitude[1]) + "′", 1),
                                    createElementVNode("text", null, "\nN: " + toDisplayString(_ctx.location.latitude[0]) + "°" + toDisplayString(_ctx.location.latitude[1]) + "′", 1)
                                ));
                            } else {
                                createCommentVNode("v-if", true);
                            }
                        ), 4);
                    } else {
                        createCommentVNode("v-if", true);
                    }
                )),
                createElementVNode("view", utsMapOf("class" to "uni-btn-v"), utsArrayOf(
                    createElementVNode("text", utsMapOf("class" to "tips"), "注意：Web和App需要正确配置地图服务商的Key并且保证Key的权限和余额足够，才能正常选择位置"),
                    createElementVNode("button", utsMapOf("type" to "primary", "onClick" to _ctx.chooseLocation), "选择位置", 8, utsArrayOf(
                        "onClick"
                    )),
                    createElementVNode("button", utsMapOf("onClick" to _ctx.clear), "清空", 8, utsArrayOf(
                        "onClick"
                    ))
                ))
            ))
        ));
    }
    open var title: String by `$data`;
    open var hasLocation: Boolean by `$data`;
    open var location: Location by `$data`;
    open var locationAddress: String by `$data`;
    open var dialogPagesNum: Number by `$data`;
    @Suppress("USELESS_CAST")
    override fun data(): Map<String, Any?> {
        return utsMapOf("title" to "chooseLocation", "hasLocation" to false, "location" to Location(latitude = utsArrayOf(), longitude = utsArrayOf()), "locationAddress" to "", "dialogPagesNum" to -1);
    }
    override fun `$initMethods`() {
        this.chooseLocation = fun() {
            uni_chooseLocation(ChooseLocationOptions(success = fun(res){
                console.log("chooseLocation success", res);
                this.hasLocation = true;
                this.location = this.formatLocation(res.longitude, res.latitude);
                this.locationAddress = res.address;
            }
            ));
            setTimeout(fun(){
                val pages = getCurrentPages();
                val page = pages[pages.length - 1];
                val dialogPages = page.getDialogPages();
                this.dialogPagesNum = dialogPages.length;
            }
            , 500);
        }
        ;
        this.formatLocation = fun(longitude: Number, latitude: Number): Location {
            val longitudeArr = longitude.toString().split(".");
            val latitudeArr = latitude.toString().split(".");
            if (longitudeArr.length > 1) {
                longitudeArr[1] = longitudeArr[1].substring(0, 2);
            }
            if (latitudeArr.length > 1) {
                latitudeArr[1] = latitudeArr[1].substring(0, 2);
            }
            return Location(longitude = longitudeArr, latitude = latitudeArr);
        }
        ;
        this.clear = fun() {
            this.hasLocation = false;
        }
        ;
    }
    open lateinit var chooseLocation: () -> Unit;
    open lateinit var formatLocation: (longitude: Number, latitude: Number) -> Location;
    open lateinit var clear: () -> Unit;
    companion object {
        val styles: Map<String, Map<String, Map<String, Any>>>
            get() {
                return normalizeCssStyles(utsArrayOf(
                    styles0
                ), utsArrayOf(
                    GenApp.styles
                ));
            }
        val styles0: Map<String, Map<String, Map<String, Any>>>
            get() {
                return utsMapOf("page-body-info" to padStyleMapOf(utsMapOf("paddingBottom" to 0, "height" to "440rpx")), "content" to padStyleMapOf(utsMapOf("backgroundImage" to "none", "backgroundColor" to "#FFFFFF", "paddingTop" to "40rpx", "paddingRight" to "40rpx", "paddingBottom" to "40rpx", "paddingLeft" to "40rpx", "alignItems" to "center")), "tips" to padStyleMapOf(utsMapOf("fontSize" to 12, "marginTop" to 15, "marginRight" to 0, "marginBottom" to 15, "marginLeft" to 0, "opacity" to 0.8)));
            }
        var inheritAttrs = true;
        var inject: Map<String, Map<String, Any?>> = utsMapOf();
        var emits: Map<String, Any?> = utsMapOf();
        var props = normalizePropsOptions(utsMapOf());
        var propsNeedCastKeys: UTSArray<String> = utsArrayOf();
        var components: Map<String, CreateVueComponent> = utsMapOf();
    }
}
